package com.ezen.FSB.dto;

public class BadgeDTO {
	
	private String mem_id; //회원 아이디
	private String mem_bg_img; //뱃지 이미지
	private String mem_bg_name; //뱃지 이름
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_bg_img() {
		return mem_bg_img;
	}
	public void setMem_bg_img(String mem_bg_img) {
		this.mem_bg_img = mem_bg_img;
	}
	public String getMem_bg_name() {
		return mem_bg_name;
	}
	public void setMem_bg_name(String mem_bg_name) {
		this.mem_bg_name = mem_bg_name;
	}
			
			
}
