package com.ezen.FSB.dto;

public class DmRoomDTO {
	private int dmr_num;
	private String dmr_name;
	private String dmr_entry;
	private String dmr_newdate;
	private int dmr_notread;
	private String dmr_hide;
	
	public int getDmr_num() {
		return dmr_num;
	}
	public void setDmr_num(int dmr_num) {
		this.dmr_num = dmr_num;
	}
	public String getDmr_name() {
		return dmr_name;
	}
	public void setDmr_name(String dmr_name) {
		this.dmr_name = dmr_name;
	}
	public String getDmr_entry() {
		return dmr_entry;
	}
	public void setDmr_entry(String dmr_entry) {
		this.dmr_entry = dmr_entry;
	}
	public String getDmr_newdate() {
		return dmr_newdate;
	}
	public void setDmr_newdate(String dmr_newdate) {
		this.dmr_newdate = dmr_newdate;
	}
	public int getDmr_notread() {
		return dmr_notread;
	}
	public void setDmr_notread(int dmr_notread) {
		this.dmr_notread = dmr_notread;
	}
	public String getDmr_hide() {
		return dmr_hide;
	}
	public void setDmr_hide(String dmr_hide) {
		this.dmr_hide = dmr_hide;
	}
}
