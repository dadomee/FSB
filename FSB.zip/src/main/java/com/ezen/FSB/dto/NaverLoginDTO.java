package com.ezen.FSB.dto;

public class NaverLoginDTO {
	private int naver_num;
	private String naver_name;
	private String naver_hp;
	private String naver_email;
	private String naver_nickname;
	
	public int getNaver_num() {
		return naver_num;
	}
	
	public void setNaver_num(int naver_num) {
		this.naver_num = naver_num;
	}
	
	public String getNaver_name() {
		return naver_name;
	}
	
	public void setNaver_name(String naver_name) {
		this.naver_name = naver_name;
	}
	
	public String getNaver_hp() {
		return naver_hp;
	}
	
	public void setNaver_hp(String naver_hp) {
		this.naver_hp = naver_hp;
	}
	
	public String getNaver_email() {
		return naver_email;
	}
	
	public void setNaver_email(String naver_email) {
		this.naver_email = naver_email;
	}
	
	public String getNaver_nickname() {
		return naver_nickname;
	}
	
	public void setNaver_nickname(String naver_nickname) {
		this.naver_nickname = naver_nickname;
	}
	
}
