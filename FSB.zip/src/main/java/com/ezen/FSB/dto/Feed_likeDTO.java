package com.ezen.FSB.dto;

public class Feed_likeDTO {
	private int fl_num;
	private int feed_num;
	private int mem_num;
	
	public int getFl_num() {
		return fl_num;
	}
	public void setFl_num(int fl_num) {
		this.fl_num = fl_num;
	}
	public int getFeed_num() {
		return feed_num;
	}
	public void setFeed_num(int feed_num) {
		this.feed_num = feed_num;
	}
	public int getMem_num() {
		return mem_num;
	}
	public void setMem_num(int mem_num) {
		this.mem_num = mem_num;
	}
}
